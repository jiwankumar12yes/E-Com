// import CartItemModel from "./cartItems.model.js";
// import jwtAuth from "../../middlewares/jwtAuth.middleware.js";
import CartItemRepository from "./cartItems.repository.js";


export default class CartItemsController {

    constructor() {
        this.cartItemsRepository = new CartItemRepository();
    }


    async add(req, res) {
        try {
            const { productID, quantity } = req.body;
            const userID = req.userID;
            console.log(userID);
            await this.cartItemsRepository.add(productID, userID, quantity);
            res.status(201).send('Cart is updated');
        } catch (err) {
            // console.log(err);
            return res.status(200).send("Something went wrong");
        }
    }

    async getAll(req, res) {
        try {
            // console.log("body: ", req.body);
            // console.log(req.headers);
            const userID = req.userID;
            // console.log(userID);
            const items = await this.cartItemsRepository.get(userID);
            return res.status(200).send(items);
        } catch (error) {
            // console.log(error);
            return res.status(200).send("Something went wrong");
        }
    }

    async delete(req, res) {
        const userID = req.userID;
        const cartItemID = req.params.id;
        const isDeeleted = await this.cartItemsRepository.delete(userID, cartItemID);
        if (!isDeeleted) {
            return res.status(404).send("Item not found");
        }
        return res.status(404).send('Cart item is removed');
    }
}