import express from "express";
import CartItemsController from "./cartItems.controller.js";
// import jwtAuth from "../../middlewares/jwtAuth.middleware.js";
// Initialize Express router.
const cartRouter = express.Router();

const cartController = new CartItemsController();

cartRouter.post('/', (req, res,) => {
    cartController.add(req, res,)
});

cartRouter.get('/', (req, res, next) => {
    cartController.getAll(req, res, next)
});

cartRouter.delete('/:id', (req, res, next) => {
    cartController.delete(req, res, next)
});
export default cartRouter;