import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import UserModel from "./user.model.js";
import UserRepository from "./user.repository.js";

export default class UserController {
  constructor() {
    this.userRepository = new UserRepository();
  }

  async signUp(req, res) {
    try {
      const { name, phoneNo, email, password, confirmPassword, type } =
        req.body;

      // Check if password and confirmPassword match
      // console.log(req.body.name, req.body.password, req.body.confirmPassword);
      // if (password !== confirmPassword) {
      //     return res.status(400).send("Passwords don't match");
      // }

      const hashedPassword = await bcrypt.hash(password, 12);
      const user = new UserModel(name, phoneNo, email, hashedPassword, type);
      await this.userRepository.signUp(user);
      res.status(201).send(user);
    } catch (err) {
      console.error(err);
      res.status(500).send("Internal Server Error");
    }
  }

  async signIn(req, res, next) {
    // console.log(req.body.email, req.body.password);
    console.log("Request body:", req.body);
    try {
      // 1. find user by email
      console.log(req.body.username);
      const user = await this.userRepository.findByEmail(req.body.email);
      if (!user) {
        return res.status(400).send("No user found");
      } else {
        // 2. Compare password password with hashed password.
        const result = await bcrypt.compare(req.body.password, user.password);
        if (result) {
          // 3. Create token.
          const token = jwt.sign(
            { userID: result.id, email: result.email },
            process.env.JWT_SECRET,
            { expiresIn: "1h" }
          );
          // 4. Send token.
          return res.status(202).send(token);
        } else {
          return res.status(400).send("Incorrect Credentials");
        }
      }
    } catch (err) {
      console.log(err);
      return res.status(200).send("Something went wrong");
    }
  }
}
