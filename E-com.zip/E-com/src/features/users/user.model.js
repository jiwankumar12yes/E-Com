
export default class UserModel {
    constructor(name, phone, email, password, type, id) {
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.password = password;
        this.type = type;
        this.id = id;
    }

    static getAll() {
        return users;
    }
}


