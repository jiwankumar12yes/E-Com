// server.js

// 1. Import express
import "./env.js";
import express, { application } from 'express';
import multer from 'multer';
import swagger, { serve } from 'swagger-ui-express';
import productRouter from './src/features/product/product.route.js';
import bodyParser from 'body-parser';
import jwtAuth from './src/middlewares/jwtAuth.middleware.js';
import userRouter from './src/features/users/user.routes.js';
import cartRouter from './src/features/cartItems/cartItems.routes.js';
import apiDocs from './swagger.json' assert {type: 'json'};
import loggerMiddleware from './src/middlewares/logger.middleware.js';
import { connectToMongoDB } from './src/config/mongodb.js';
import { ApplicationError } from './src/error-handler/applicationError.js';

// port
const port = 5500;

// 2. Create Server
const server = express();


// Set the view engine to use EJS
server.set('view engine', 'ejs');


server.use(bodyParser.json());
server.use(express.urlencoded({ extended: true }));


// for all requests related to product, redirect to product routes.
// localhost:3200/api/products
server.use("/api-docs", swagger.serve, swagger.setup(apiDocs));
server.use(loggerMiddleware);
server.use("/api/products", jwtAuth, productRouter);
server.use("/api/cartitems", jwtAuth, cartRouter);
server.use("/api/users", userRouter);

// 3. Default request handler
server.get('/', (req, res) => {
    res.send("Welcome to Ecommerce APIs");
});

// Error handle for application
server.use((err, req, res, next) => {
    if (err instanceof ApplicationError) {
        res.status(err.code).send(err.message);
    }
    // server error
    console.log(err);
    res.status(500).send("Something went wrong , please try later");
})

// 4. Middleware to handle 404 requests
server.use((req, res) => {
    res.status(404).send("API not found");
})


server.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
    connectToMongoDB();
});
